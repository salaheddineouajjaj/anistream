
import React, { useEffect, useState } from 'react';
import { fetchAnimeList } from '../services/anilist';
import { Anime } from '../types';
import AnimeCard from '../components/AnimeCard';
import { Play, Info, Sparkles, TrendingUp, ChevronLeft, ChevronRight, Star } from 'lucide-react';
import { Link } from 'react-router-dom';

const Home: React.FC = () => {
  const [trending, setTrending] = useState<Anime[]>([]);
  const [popular, setPopular] = useState<Anime[]>([]);
  const [featured, setFeatured] = useState<Anime[]>([]);
  const [activeIndex, setActiveIndex] = useState(0);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const loadData = async () => {
      try {
        const trendData = await fetchAnimeList({ sort: ['TRENDING_DESC'], perPage: 15 });
        const popData = await fetchAnimeList({ sort: ['POPULARITY_DESC'], perPage: 12 });
        
        setTrending(trendData.media);
        setPopular(popData.media);
        setFeatured(trendData.media.slice(0, 5));
      } catch (error) {
        console.error("Home load error", error);
      } finally {
        setLoading(false);
      }
    };
    loadData();
  }, []);

  const nextSlide = () => setActiveIndex((prev) => (prev + 1) % featured.length);
  const prevSlide = () => setActiveIndex((prev) => (prev - 1 + featured.length) % featured.length);

  if (loading) return (
    <div className="flex items-center justify-center min-h-screen">
      <div className="relative w-24 h-24">
        <div className="absolute inset-0 border-4 border-amber-500/10 rounded-full"></div>
        <div className="absolute inset-0 border-4 border-t-amber-500 rounded-full animate-spin"></div>
        <div className="absolute inset-0 flex items-center justify-center">
          <Sparkles className="text-amber-500 animate-pulse" size={32} />
        </div>
      </div>
    </div>
  );

  return (
    <div className="space-y-32 pb-40">
      {/* 3D FEATURED SLIDER */}
      <section className="relative h-[100vh] w-full flex items-center justify-center overflow-hidden pt-20">
        <div className="absolute inset-0 pointer-events-none overflow-hidden">
            <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-purple-600/10 blur-[150px] rounded-full"></div>
            <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-amber-500/10 blur-[150px] rounded-full"></div>
        </div>

        <div className="relative w-full max-w-7xl mx-auto h-[600px] perspective-container flex items-center justify-center">
          {featured.map((anime, idx) => {
            const isCenter = idx === activeIndex;
            const isLeft = idx === (activeIndex - 1 + featured.length) % featured.length;
            const isRight = idx === (activeIndex + 1) % featured.length;
            const isHidden = !isCenter && !isLeft && !isRight;

            let transform = "scale(0.6) translateZ(-500px) rotateY(0deg)";
            let opacity = 0;
            let zIndex = 0;

            if (isCenter) {
              transform = "scale(1) translateZ(100px) rotateY(0deg)";
              opacity = 1;
              zIndex = 30;
            } else if (isLeft) {
              transform = "scale(0.8) translateX(-350px) translateZ(-200px) rotateY(35deg)";
              opacity = 0.5;
              zIndex = 20;
            } else if (isRight) {
              transform = "scale(0.8) translateX(350px) translateZ(-200px) rotateY(-35deg)";
              opacity = 0.5;
              zIndex = 20;
            }

            return (
              <div
                key={anime.id}
                className="absolute w-[350px] md:w-[450px] h-[600px] transition-all duration-1000 ease-out cursor-pointer group"
                style={{ transform, opacity, zIndex, display: isHidden ? 'none' : 'block' }}
                onClick={() => isCenter ? null : setActiveIndex(idx)}
              >
                <div className={`relative w-full h-full rounded-[2.5rem] overflow-hidden border-2 transition-all duration-500 ${isCenter ? 'border-amber-500 shadow-[0_0_50px_rgba(250,204,21,0.3)]' : 'border-white/5 shadow-2xl'}`}>
                  <img src={anime.coverImage.extraLarge} className="w-full h-full object-cover" alt="" />
                  <div className={`absolute inset-0 bg-gradient-to-t from-black via-black/20 to-transparent flex flex-col justify-end p-8 transition-opacity duration-500 ${isCenter ? 'opacity-100' : 'opacity-0'}`}>
                    <div className="flex items-center gap-3 mb-4">
                       <span className="bg-amber-500 text-black text-[10px] font-black px-3 py-1 rounded-full tracking-widest uppercase">Legendary</span>
                       <div className="flex items-center gap-1 text-amber-500 font-bold text-sm">
                         <Star size={14} fill="currentColor" /> {anime.averageScore / 10}
                       </div>
                    </div>
                    <h2 className="text-3xl md:text-4xl font-black font-arabic mb-4 line-clamp-2 leading-tight tracking-tighter">
                      {anime.title.english || anime.title.romaji}
                    </h2>
                    <div className="flex gap-4">
                      <Link to={`/watch/${anime.id}/1`} className="flex-grow flex items-center justify-center gap-2 bg-amber-500 hover:bg-amber-400 text-black font-black py-4 rounded-2xl transition-all">
                        <Play size={20} fill="black" /> WATCH NOW
                      </Link>
                      <Link to={`/anime/${anime.id}`} className="w-16 flex items-center justify-center bg-white/10 hover:bg-white/20 backdrop-blur-md rounded-2xl text-white transition-all border border-white/10">
                        <Info size={24} />
                      </Link>
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {/* Controls */}
        <div className="absolute bottom-10 left-1/2 -translate-x-1/2 flex items-center gap-8">
           <button onClick={prevSlide} className="w-14 h-14 rounded-full border border-amber-500/20 flex items-center justify-center text-amber-500 hover:bg-amber-500 hover:text-black transition-all">
              <ChevronLeft size={28} />
           </button>
           <div className="flex gap-2">
              {featured.map((_, i) => (
                <div key={i} className={`h-1.5 rounded-full transition-all duration-500 ${i === activeIndex ? 'w-8 bg-amber-500' : 'w-2 bg-white/20'}`} />
              ))}
           </div>
           <button onClick={nextSlide} className="w-14 h-14 rounded-full border border-amber-500/20 flex items-center justify-center text-amber-500 hover:bg-amber-500 hover:text-black transition-all">
              <ChevronRight size={28} />
           </button>
        </div>
      </section>

      {/* DISCOVERY GRID */}
      <div className="max-w-7xl mx-auto px-4 space-y-32">
        {/* Trending */}
        <section>
          <div className="flex items-center justify-between mb-12">
            <div className="flex items-center gap-4">
              <div className="w-14 h-14 bg-amber-500/10 border border-amber-500/20 rounded-[1.25rem] flex items-center justify-center text-amber-500 gold-glow">
                <TrendingUp size={28} />
              </div>
              <div>
                <h2 className="text-3xl font-black font-arabic tracking-tight">Rising Dimension</h2>
                <p className="text-[10px] uppercase tracking-[0.3em] font-bold text-slate-500">The most viewed chronicles</p>
              </div>
            </div>
            <Link to="/browse?sort=TRENDING_DESC" className="group flex items-center gap-3 text-amber-500 text-xs font-black tracking-widest uppercase">
               View Grid <div className="w-6 h-px bg-amber-500 transition-all group-hover:w-12" />
            </Link>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-8">
            {trending.map(anime => (
              <AnimeCard key={anime.id} anime={anime} />
            ))}
          </div>
        </section>

        {/* Mystery Box CTA */}
        <section className="relative overflow-hidden rounded-[4rem] p-16 md:p-32 text-center border-2 border-amber-500/10 bg-[#050505]">
           <div className="absolute top-0 right-0 -translate-y-1/2 translate-x-1/2 w-[500px] h-[500px] bg-purple-600/5 blur-[120px] rounded-full"></div>
           <div className="absolute bottom-0 left-0 translate-y-1/2 -translate-x-1/2 w-[500px] h-[500px] bg-amber-500/5 blur-[120px] rounded-full"></div>
           
           <div className="relative z-10 max-w-3xl mx-auto space-y-10">
              <div className="w-20 h-20 bg-amber-500/10 border border-amber-500/20 rounded-3xl flex items-center justify-center text-amber-500 mx-auto floating">
                <Sparkles size={40} />
              </div>
              <h2 className="text-4xl md:text-7xl font-black font-arabic tracking-tighter leading-tight">
                Enter the <span className="text-gold-gradient">Celestial Gate</span>
              </h2>
              <p className="text-slate-500 text-lg md:text-xl font-medium leading-relaxed">
                Connect your soul to the infinite catalog of legends. Translated by high priests, streamed through the void.
              </p>
              <div className="flex flex-col sm:flex-row gap-6 justify-center items-center">
                 <button className="relative overflow-hidden bg-amber-500 text-black px-12 py-5 rounded-[2rem] font-black tracking-widest shadow-[0_0_30px_rgba(250,204,21,0.3)] hover:scale-105 active:scale-95 transition-all">
                    <span className="relative z-10">TRANSCEND NOW</span>
                    <div className="absolute inset-0 gold-shimmer opacity-30"></div>
                 </button>
              </div>
           </div>
        </section>
      </div>
    </div>
  );
};

export default Home;
