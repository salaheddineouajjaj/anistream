
import React, { useEffect, useState, useRef, useCallback } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { fetchAnimeDetails } from '../services/anilist';
import { 
  Play, Pause, Volume2, Maximize, Settings, 
  ChevronLeft, ChevronRight, SkipForward,
  MessageSquare, Share2, AlertCircle, Monitor,
  Type, Subtitles, Zap
} from 'lucide-react';

const SERVERS = [
  { name: 'AURUM-1', url: 'https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8', quality: 'GOLD', health: 'perfect' },
  { name: 'NEBULA-X', url: 'https://bitdash-a.akamaihd.net/content/sintel/hls/playlist.m3u8', quality: '4K', health: 'stable' },
  { name: 'VOID-ZERO', url: 'https://demo.unified-streaming.com/k8s/features/stable/video/tears-of-steel/tears-of-steel.ism/.m3u8', quality: '1080P', health: 'legacy' }
];

const Watch: React.FC = () => {
  const { id, episode } = useParams<{ id: string, episode: string }>();
  const navigate = useNavigate();
  const [anime, setAnime] = useState<any>(null);
  const [currentServer, setCurrentServer] = useState(SERVERS[0]);
  const [isPlaying, setIsPlaying] = useState(false);
  const [showControls, setShowControls] = useState(true);
  const [progress, setProgress] = useState(0);
  const [duration, setDuration] = useState(0);
  const [volume, setVolume] = useState(0.8);
  const [showSettings, setShowSettings] = useState(false);
  const [showSubtitles, setShowSubtitles] = useState(true);
  const [subSize, setSubSize] = useState('medium');
  const [loading, setLoading] = useState(true);
  
  const videoRef = useRef<HTMLVideoElement>(null);
  const controlsTimeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => {
    const loadDetails = async () => {
      if (!id) return;
      try {
        const data = await fetchAnimeDetails(parseInt(id));
        setAnime(data);
        
        const history = JSON.parse(localStorage.getItem('history') || '[]');
        const updatedHistory = [{
          id: data.id,
          title: data.title,
          cover: data.coverImage.large,
          episode: parseInt(episode || '1'),
          timestamp: Date.now()
        }, ...history.filter((h: any) => h.id !== data.id)].slice(0, 50);
        localStorage.setItem('history', JSON.stringify(updatedHistory));
      } catch (error) {
        console.error("Watch error", error);
      } finally {
        setLoading(false);
      }
    };
    loadDetails();
  }, [id, episode]);

  const handleMouseMove = () => {
    setShowControls(true);
    if (controlsTimeoutRef.current) clearTimeout(controlsTimeoutRef.current);
    controlsTimeoutRef.current = setTimeout(() => {
      if (isPlaying) setShowControls(false);
    }, 3000);
  };

  const togglePlay = useCallback(() => {
    if (videoRef.current) {
      if (isPlaying) videoRef.current.pause();
      else videoRef.current.play();
      setIsPlaying(!isPlaying);
    }
  }, [isPlaying]);

  const handleTimeUpdate = () => {
    if (videoRef.current) {
      const p = (videoRef.current.currentTime / videoRef.current.duration) * 100;
      setProgress(p);
      if (Math.floor(videoRef.current.currentTime) % 10 === 0) {
        localStorage.setItem(`progress_${id}_${episode}`, videoRef.current.currentTime.toString());
      }
    }
  };

  const handleSeek = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (videoRef.current) {
      const val = parseFloat(e.target.value);
      videoRef.current.currentTime = (val / 100) * videoRef.current.duration;
      setProgress(val);
    }
  };

  const toggleFullscreen = () => {
    if (videoRef.current?.parentElement) {
      if (document.fullscreenElement) document.exitFullscreen();
      else videoRef.current.parentElement.requestFullscreen();
    }
  };

  const skip = (seconds: number) => {
    if (videoRef.current) videoRef.current.currentTime += seconds;
  };

  if (loading) return (
    <div className="min-h-screen flex items-center justify-center bg-[#050505]">
       <div className="w-16 h-16 border-4 border-amber-500/20 border-t-amber-500 rounded-full animate-spin"></div>
    </div>
  );

  return (
    <div className="max-w-7xl mx-auto px-4 py-12 space-y-12">
      {/* Top Header */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-6">
        <div className="space-y-4">
          <Link to={`/anime/${id}`} className="inline-flex items-center gap-2 text-amber-500 hover:text-amber-400 font-black text-xs uppercase tracking-[0.2em] group">
            <ChevronLeft size={16} className="group-hover:-translate-x-1 transition-transform" />
            BACK TO PORTAL
          </Link>
          <h1 className="text-3xl md:text-5xl font-black font-arabic tracking-tighter">
            {anime?.title.english || anime?.title.romaji} <span className="text-amber-500">/ Ep {episode}</span>
          </h1>
        </div>
        <div className="flex gap-3">
          <button className="flex items-center gap-2 px-6 py-3 bg-white/5 border border-amber-500/20 rounded-2xl text-amber-500 font-bold text-sm hover:bg-amber-500/10 transition-all">
            <Share2 size={18} /> TRANSMIT
          </button>
        </div>
      </div>

      {/* Cosmic Player Container */}
      <div 
        className="relative aspect-video w-full bg-black rounded-[2rem] overflow-hidden shadow-[0_0_50px_rgba(0,0,0,1)] border border-amber-500/10 group"
        onMouseMove={handleMouseMove}
      >
        <video 
          ref={videoRef}
          className="w-full h-full cursor-pointer"
          src={currentServer.url}
          onTimeUpdate={handleTimeUpdate}
          onLoadedMetadata={() => {
            setDuration(videoRef.current?.duration || 0);
            const saved = localStorage.getItem(`progress_${id}_${episode}`);
            if (saved && videoRef.current) videoRef.current.currentTime = parseFloat(saved);
          }}
          onClick={togglePlay}
          playsInline
        />

        {/* Subtitles Overlay */}
        {showSubtitles && isPlaying && (
          <div className="absolute bottom-24 left-0 w-full px-12 text-center pointer-events-none z-20">
            <p className={`font-arabic text-white drop-shadow-[0_2px_4px_rgba(0,0,0,1)] bg-black/60 inline-block px-6 py-2 rounded-2xl border border-amber-500/20 ${
              subSize === 'small' ? 'text-xl' : subSize === 'large' ? 'text-5xl' : 'text-3xl'
            }`}>
              أهلاً بكم في عالم الأنمي الساحر
            </p>
          </div>
        )}

        {/* Controls Overlay */}
        <div className={`absolute inset-0 bg-gradient-to-t from-black via-transparent to-black/40 transition-opacity duration-500 ${showControls ? 'opacity-100' : 'opacity-0 pointer-events-none'}`}>
          <div className="absolute top-0 left-0 w-full p-8 flex justify-between items-center">
             <div className="flex items-center gap-3 bg-amber-500 text-black px-4 py-1.5 rounded-full text-[10px] font-black uppercase tracking-widest">
                <Zap size={14} fill="black" /> Universal Stream
             </div>
             <button onClick={() => setShowSettings(!showSettings)} className="w-12 h-12 flex items-center justify-center bg-white/10 hover:bg-amber-500/20 rounded-2xl transition-all text-amber-500 backdrop-blur-md">
                <Settings size={24} />
             </button>
          </div>

          <div className="absolute bottom-0 left-0 w-full p-8 space-y-6">
             <div className="relative group/seek h-2 flex items-center">
               <input 
                 type="range"
                 className="w-full h-1 bg-white/20 rounded-full appearance-none cursor-pointer accent-amber-500"
                 min="0" max="100" value={progress} onChange={handleSeek}
               />
               <div className="absolute top-0 left-0 h-1 bg-gradient-to-r from-amber-500 to-purple-500 rounded-full pointer-events-none" style={{ width: `${progress}%` }} />
             </div>

             <div className="flex items-center justify-between">
                <div className="flex items-center gap-8">
                  <button onClick={togglePlay} className="text-amber-500 hover:scale-110 transition-transform">
                    {isPlaying ? <Pause size={36} fill="currentColor" /> : <Play size={36} fill="currentColor" />}
                  </button>
                  <button onClick={() => skip(10)} className="text-white hover:text-amber-500 transition-colors">
                    <SkipForward size={28} />
                  </button>
                  <div className="text-sm font-black text-amber-500/70 font-mono">
                    {Math.floor((progress/100)*duration/60).toString().padStart(2, '0')}:{Math.floor(((progress/100)*duration)%60).toString().padStart(2, '0')} 
                    <span className="mx-2 text-slate-700">/</span>
                    {Math.floor(duration/60).toString().padStart(2, '0')}:{Math.floor(duration%60).toString().padStart(2, '0')}
                  </div>
                </div>

                <div className="flex items-center gap-5">
                   <button 
                    onClick={() => setShowSubtitles(!showSubtitles)}
                    className={`p-3 rounded-2xl transition-all ${showSubtitles ? 'bg-amber-500 text-black shadow-[0_0_20px_rgba(251,191,36,0.4)]' : 'bg-white/10 text-white/50'}`}
                   >
                     <Type size={22} />
                   </button>
                   <button onClick={toggleFullscreen} className="text-amber-500 hover:scale-110 transition-transform">
                     <Maximize size={24} />
                   </button>
                </div>
             </div>
          </div>
        </div>
      </div>

      {/* Server & Info Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
        <div className="lg:col-span-2 space-y-12">
          <section className="glass rounded-[2.5rem] p-10 space-y-8">
             <div className="flex items-center gap-4">
                <div className="p-3 bg-amber-500/10 rounded-2xl text-amber-500">
                  <Monitor size={32} />
                </div>
                <div>
                   <h3 className="text-2xl font-black font-arabic">Choose Dimension</h3>
                   <p className="text-xs font-bold text-slate-500 uppercase tracking-widest">Streaming Server Selector</p>
                </div>
             </div>
             <div className="grid grid-cols-1 sm:grid-cols-3 gap-5">
                {SERVERS.map(s => (
                  <button
                    key={s.name}
                    onClick={() => {
                      const time = videoRef.current?.currentTime || 0;
                      setCurrentServer(s);
                      setTimeout(() => { if (videoRef.current) videoRef.current.currentTime = time; }, 100);
                    }}
                    className={`relative p-6 rounded-3xl border text-left transition-all ${
                      currentServer.name === s.name ? 'bg-amber-500 border-amber-400 shadow-[0_0_30px_rgba(251,191,36,0.2)] scale-[1.02]' : 'bg-[#111] border-white/5 hover:border-amber-500/30'
                    }`}
                  >
                    <div className={`font-black text-lg mb-1 ${currentServer.name === s.name ? 'text-black' : 'text-amber-500'}`}>{s.name}</div>
                    <div className="flex items-center justify-between">
                      <span className={`text-[10px] font-black tracking-widest ${currentServer.name === s.name ? 'text-black/60' : 'text-slate-600'}`}>{s.quality}</span>
                      <div className="flex items-center gap-2">
                        <span className={`text-[10px] font-black uppercase ${s.health === 'perfect' ? 'text-green-500' : 'text-amber-600'}`}>{s.health}</span>
                        <div className={`w-2 h-2 rounded-full ${s.health === 'perfect' ? 'bg-green-500 animate-pulse' : 'bg-amber-600'}`} />
                      </div>
                    </div>
                  </button>
                ))}
             </div>
          </section>
        </div>

        {/* Episode Navigator */}
        <div className="space-y-6">
           <div className="glass rounded-[2.5rem] p-8 h-fit sticky top-28 border border-purple-500/20 shadow-[0_0_40px_rgba(126,34,206,0.1)]">
              <h3 className="text-xl font-black font-arabic mb-8 flex items-center gap-3">
                <div className="w-1 h-6 bg-purple-500 rounded-full" />
                Chronicles
              </h3>
              <div className="space-y-3 max-h-[600px] overflow-y-auto pr-2 custom-scroll">
                 {Array.from({ length: anime?.episodes || 12 }).map((_, i) => (
                   <Link
                    key={i}
                    to={`/watch/${id}/${i + 1}`}
                    className={`flex items-center gap-5 p-4 rounded-2xl border transition-all ${
                      parseInt(episode || '1') === i + 1 ? 'bg-purple-900/20 border-purple-500 text-purple-300' : 'bg-[#111] border-white/5 hover:border-amber-500/30'
                    }`}
                   >
                     <div className={`w-12 h-12 rounded-xl flex items-center justify-center font-black text-lg shrink-0 ${
                        parseInt(episode || '1') === i + 1 ? 'bg-purple-500 text-white' : 'bg-[#050505] text-amber-500'
                     }`}>
                       {(i + 1).toString().padStart(2, '0')}
                     </div>
                     <div className="flex-grow">
                        <div className="text-sm font-black">Episode {i + 1}</div>
                        <div className="text-[10px] font-bold text-slate-600 uppercase tracking-widest">Arabic Manifest</div>
                     </div>
                   </Link>
                 ))}
              </div>
           </div>
        </div>
      </div>
    </div>
  );
};

export default Watch;
