
import React, { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { fetchAnimeDetails } from '../services/anilist';
import { Anime } from '../types';
import { Play, Heart, Share2, Star, Calendar, Clock, List, ChevronRight } from 'lucide-react';
import AnimeCard from '../components/AnimeCard';

const Details: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const [anime, setAnime] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [isWatchlisted, setIsWatchlisted] = useState(false);

  useEffect(() => {
    const loadDetails = async () => {
      if (!id) return;
      setLoading(true);
      try {
        const data = await fetchAnimeDetails(parseInt(id));
        setAnime(data);
        
        // Check watchlist in local storage
        const watchlist = JSON.parse(localStorage.getItem('watchlist') || '[]');
        setIsWatchlisted(watchlist.includes(parseInt(id)));
      } catch (error) {
        console.error("Failed to load details", error);
      } finally {
        setLoading(false);
      }
    };
    loadDetails();
    window.scrollTo(0, 0);
  }, [id]);

  const toggleWatchlist = () => {
    if (!id) return;
    const animeId = parseInt(id);
    let watchlist = JSON.parse(localStorage.getItem('watchlist') || '[]');
    if (isWatchlisted) {
      watchlist = watchlist.filter((item: number) => item !== animeId);
    } else {
      watchlist.push(animeId);
    }
    localStorage.setItem('watchlist', JSON.stringify(watchlist));
    setIsWatchlisted(!isWatchlisted);
  };

  if (loading) return (
    <div className="min-h-screen flex items-center justify-center">
      <div className="w-12 h-12 border-4 border-indigo-500 border-t-transparent rounded-full animate-spin"></div>
    </div>
  );

  if (!anime) return <div className="p-20 text-center">Anime not found.</div>;

  const recommendations = anime.recommendations?.nodes?.map((n: any) => n.mediaRecommendation).filter(Boolean).slice(0, 6) || [];

  return (
    <div className="pb-20">
      {/* Banner */}
      <div className="relative h-[40vh] md:h-[50vh] w-full">
        <div className="absolute inset-0">
          <img 
            src={anime.bannerImage || anime.coverImage.extraLarge} 
            className="w-full h-full object-cover"
            alt="Banner"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/60 to-transparent" />
        </div>
      </div>

      {/* Content */}
      <div className="max-w-7xl mx-auto px-4 -mt-32 relative z-10">
        <div className="flex flex-col md:flex-row gap-8">
          
          {/* Left: Poster & Basic Info */}
          <div className="w-full md:w-72 shrink-0 space-y-6">
            <div className="aspect-[2/3] rounded-2xl overflow-hidden shadow-2xl border-4 border-slate-950 bg-slate-900">
              <img 
                src={anime.coverImage.extraLarge} 
                className="w-full h-full object-cover"
                alt="Poster"
              />
            </div>

            <div className="flex flex-col gap-3">
              <Link 
                to={`/watch/${anime.id}/1`}
                className="flex items-center justify-center gap-2 bg-indigo-600 hover:bg-indigo-500 text-white font-bold py-3.5 rounded-xl shadow-lg shadow-indigo-600/20 transition-all active:scale-95"
              >
                <Play className="fill-white" size={20} />
                WATCH NOW
              </Link>
              <div className="grid grid-cols-2 gap-3">
                <button 
                  onClick={toggleWatchlist}
                  className={`flex items-center justify-center gap-2 py-3 rounded-xl border transition-all ${
                    isWatchlisted ? 'bg-rose-500 border-rose-400 text-white' : 'bg-white/5 border-white/10 text-slate-300 hover:bg-white/10'
                  }`}
                >
                  <Heart size={20} fill={isWatchlisted ? "currentColor" : "none"} />
                  {isWatchlisted ? 'In List' : 'Watchlist'}
                </button>
                <button className="flex items-center justify-center gap-2 bg-white/5 border border-white/10 hover:bg-white/10 text-slate-300 py-3 rounded-xl transition-all">
                  <Share2 size={20} />
                  Share
                </button>
              </div>
            </div>

            {/* Sidebar Stats */}
            <div className="glass rounded-2xl p-6 space-y-4">
               <div className="flex justify-between items-center text-sm">
                 <span className="text-slate-500">Format</span>
                 <span className="font-semibold">{anime.format || 'TV'}</span>
               </div>
               <div className="flex justify-between items-center text-sm">
                 <span className="text-slate-500">Status</span>
                 <span className="font-semibold text-indigo-400">{anime.status}</span>
               </div>
               <div className="flex justify-between items-center text-sm">
                 <span className="text-slate-500">Season</span>
                 <span className="font-semibold uppercase">{anime.season} {anime.seasonYear}</span>
               </div>
               <div className="flex justify-between items-center text-sm">
                 <span className="text-slate-500">Episodes</span>
                 <span className="font-semibold">{anime.episodes || '??'}</span>
               </div>
            </div>
          </div>

          {/* Right: Main Details */}
          <div className="flex-grow pt-4 md:pt-36">
            <div className="flex flex-wrap items-center gap-2 mb-4">
              {anime.genres.map((g: string) => (
                <Link 
                  key={g} 
                  to={`/browse?genre=${g}`}
                  className="bg-indigo-500/10 border border-indigo-500/20 text-indigo-400 text-xs font-bold px-3 py-1 rounded-full hover:bg-indigo-500/20 transition-colors"
                >
                  {g}
                </Link>
              ))}
            </div>

            <h1 className="text-4xl md:text-5xl font-black mb-2 text-white leading-tight">
              {anime.title.english || anime.title.romaji}
            </h1>
            <h2 className="text-lg text-slate-500 font-medium mb-6">
              {anime.title.romaji} • {anime.title.native}
            </h2>

            <div className="flex flex-wrap items-center gap-8 mb-8">
              <div className="flex items-center gap-2">
                <Star className="text-amber-400" size={24} fill="currentColor" />
                <div>
                  <div className="text-xl font-black text-amber-400">{anime.averageScore / 10}</div>
                  <div className="text-[10px] text-slate-500 uppercase tracking-widest font-bold">Rating</div>
                </div>
              </div>
              {anime.nextAiringEpisode && (
                <div className="flex items-center gap-2 text-indigo-400">
                  <Calendar size={24} />
                  <div>
                    <div className="text-sm font-bold">EP {anime.nextAiringEpisode.episode}</div>
                    <div className="text-[10px] text-slate-500 uppercase tracking-widest font-bold">Next Airing</div>
                  </div>
                </div>
              )}
            </div>

            <div className="mb-12">
              <h3 className="text-lg font-bold mb-4 flex items-center gap-2">
                <List className="text-indigo-500" size={20} />
                Synopsis
              </h3>
              <div 
                className="text-slate-400 leading-relaxed font-light"
                dangerouslySetInnerHTML={{ __html: anime.description }} 
              />
            </div>

            {/* Episodes List (Simulated for this demo environment) */}
            <div className="mb-12">
               <div className="flex items-center justify-between mb-6">
                 <h3 className="text-xl font-bold">Episodes</h3>
                 <span className="text-slate-500 text-sm">Total: {anime.episodes || '??'}</span>
               </div>
               <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                 {Array.from({ length: Math.min(anime.episodes || 12, 12) }).map((_, i) => (
                   <Link 
                    key={i}
                    to={`/watch/${anime.id}/${i + 1}`}
                    className="group bg-white/5 border border-white/10 rounded-xl p-3 flex items-center gap-4 hover:border-indigo-500/50 hover:bg-white/10 transition-all"
                   >
                     <div className="relative w-20 h-14 bg-slate-800 rounded-lg overflow-hidden shrink-0">
                       <img 
                          src={anime.coverImage.large} 
                          className="w-full h-full object-cover opacity-50 blur-sm"
                          alt="Episode"
                       />
                       <div className="absolute inset-0 flex items-center justify-center">
                         <Play size={16} className="text-white opacity-0 group-hover:opacity-100 transition-opacity" />
                         <span className="text-xs font-bold text-white group-hover:opacity-0 transition-opacity">EP {i + 1}</span>
                       </div>
                     </div>
                     <div className="flex-grow">
                        <div className="text-sm font-bold truncate">Episode {i + 1}</div>
                        <div className="text-[10px] text-slate-500 uppercase">24 Minutes</div>
                     </div>
                   </Link>
                 ))}
               </div>
            </div>

            {/* Recommendations */}
            {recommendations.length > 0 && (
              <section>
                <h3 className="text-xl font-bold mb-6">You Might Also Like</h3>
                <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-4">
                  {recommendations.map((rec: any) => (
                    <Link key={rec.id} to={`/anime/${rec.id}`} className="group space-y-2">
                       <div className="aspect-[2/3] rounded-xl overflow-hidden shadow-lg border border-white/5">
                         <img 
                          src={rec.coverImage.large} 
                          className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500" 
                          alt={rec.title.romaji}
                         />
                       </div>
                       <div className="text-xs font-semibold line-clamp-1 group-hover:text-indigo-400 transition-colors">
                        {rec.title.english || rec.title.romaji}
                       </div>
                    </Link>
                  ))}
                </div>
              </section>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Details;
