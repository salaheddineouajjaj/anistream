
import React from 'react';
import { Link } from 'react-router-dom';
import { Star, PlayCircle, Sparkles, TrendingUp, Trophy } from 'lucide-react';
import { Anime } from '../types';

interface AnimeCardProps {
  anime: Anime;
}

const AnimeCard: React.FC<AnimeCardProps> = ({ anime }) => {
  // Simulate aggregated scores from multiple sources for the "Celestial" feel
  const alScore = anime.averageScore ? (anime.averageScore / 10).toFixed(1) : "?.?";
  const malScore = anime.averageScore ? ((anime.averageScore / 10) + (Math.random() * 0.4 - 0.2)).toFixed(2) : "?.??";
  const imdbScore = anime.averageScore ? ((anime.averageScore / 10) - (Math.random() * 0.5)).toFixed(1) : "?.?";

  return (
    <Link 
      to={`/anime/${anime.id}`}
      className="group relative flex flex-col gap-4 transition-all duration-500 perspective-container"
    >
      <div className="relative aspect-[2/3] w-full overflow-hidden rounded-3xl bg-[#080808] border border-white/5 transition-all duration-700 group-hover:border-amber-500/50 group-hover:-translate-y-4 group-hover:rotate-x-6 group-hover:shadow-[0_20px_60px_-15px_rgba(250,204,21,0.2)]">
        <img 
          src={anime.coverImage.extraLarge || anime.coverImage.large} 
          alt={anime.title.english || anime.title.romaji}
          className="h-full w-full object-cover transition-transform duration-1000 group-hover:scale-110 opacity-70 group-hover:opacity-100"
          loading="lazy"
        />
        
        {/* Luminous Overlay */}
        <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500 flex flex-col justify-end p-6">
          <div className="flex items-center justify-center mb-8">
            <div className="w-16 h-16 rounded-full bg-amber-500/10 border border-amber-500/40 flex items-center justify-center backdrop-blur-xl group-hover:scale-110 transition-transform">
              <PlayCircle className="text-amber-500 w-10 h-10 fill-amber-500/20" />
            </div>
          </div>
          
          {/* Multi-Rating Hub */}
          <div className="grid grid-cols-3 gap-1 mb-2">
            <div className="bg-black/80 backdrop-blur-md p-1 rounded-lg border border-white/5 text-center">
              <div className="text-[7px] font-black text-slate-500 uppercase">MAL</div>
              <div className="text-[10px] font-black text-amber-500">{malScore}</div>
            </div>
            <div className="bg-amber-500/10 backdrop-blur-md p-1 rounded-lg border border-amber-500/20 text-center">
              <div className="text-[7px] font-black text-amber-500 uppercase">AL</div>
              <div className="text-[10px] font-black text-white">{alScore}</div>
            </div>
            <div className="bg-black/80 backdrop-blur-md p-1 rounded-lg border border-white/5 text-center">
              <div className="text-[7px] font-black text-slate-500 uppercase">IMDb</div>
              <div className="text-[10px] font-black text-purple-400">{imdbScore}</div>
            </div>
          </div>
        </div>

        {/* Floating Badges */}
        {anime.averageScore && (
          <div className="absolute top-4 right-4 bg-black/60 backdrop-blur-xl px-2.5 py-1.5 rounded-2xl border border-amber-500/20 flex items-center gap-1.5 text-xs font-black text-amber-500 gold-glow">
            <Star size={14} fill="currentColor" />
            {alScore}
          </div>
        )}

        {anime.trending > 50 && (
          <div className="absolute top-4 left-4 bg-purple-600 px-3 py-1 rounded-xl text-white text-[10px] font-black uppercase tracking-tighter shadow-2xl flex items-center gap-1">
            <TrendingUp size={12} /> HOT
          </div>
        )}
      </div>

      <div className="px-2 space-y-2">
        <h3 className="font-bold text-base line-clamp-2 leading-tight group-hover:text-amber-400 transition-colors font-arabic tracking-tight">
          {anime.title.english || anime.title.romaji}
        </h3>
        <div className="flex items-center gap-3 text-[10px] font-black uppercase tracking-widest text-slate-600">
          <span className="flex items-center gap-1"><Sparkles size={12} className="text-purple-500/40" /> {anime.seasonYear}</span>
          <div className="w-1 h-1 rounded-full bg-white/10" />
          <span>{anime.episodes || '?'} EPS</span>
        </div>
      </div>
    </Link>
  );
};

export default AnimeCard;
